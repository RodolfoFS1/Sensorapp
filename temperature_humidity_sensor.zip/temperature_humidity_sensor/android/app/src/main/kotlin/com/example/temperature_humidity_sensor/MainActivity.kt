package com.example.temperature_humidity_sensor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
